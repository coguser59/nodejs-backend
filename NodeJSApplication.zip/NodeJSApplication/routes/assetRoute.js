const AssetDao = require('../models/assetDao');

class assetRoute {
	/**
    * Handles the various APIs for displaying and managing Assets
    * @param {AssetDao} AssetDao
    */
	constructor(AssetDao) {
		this.AssetDao = AssetDao;
	}

	async showAssets(req, res) {
		const querySpec = {
			query: 'SELECT * FROM assetData'
		};

		const items = await this.AssetDao.find(querySpec);
		res.send(items);
	}

	async showAsset(req, res) {
		console.log(req.body);
		const querySpec = {
			query: 'SELECT * FROM assetData a where a.assetId = @assetId',
			parameters: [
				{
					name: '@assetId',
					value: req.body.assetId
				}
			]
		};

		const items = await this.AssetDao.find(querySpec);
		res.send(JSON.stringify(items));
	}

	async showDailyAssetData(req, res) {
		console.log(req.body);
		const querySpec = {
			query: 'SELECT * FROM AssetData a where a.createdTimeStamp >= GetCurrentDateTime()',
		};

		const items = await this.AssetDao.find(querySpec);
		res.send(JSON.stringify(items));
	}

	async addAsset(req, res) {
		const item = req.body;

		const doc = await this.AssetDao.addItem(item);
		res.send('Completed adding....' + JSON.stringify(doc));
	}

	async deleteAsset(req, res) {
    
		const querySpec = {
			query: 'SELECT * FROM assetData a where a.assetId = @assetId',
			parameters: [
				{
					name: '@assetId',
					value: req.body.assetId
				}
			]
		};

		const items = await this.AssetDao.find(querySpec);
    console.log('Body from select: ' + JSON.stringify(items));

		const itemId = items[0].id;
		console.log('Id from select: ' + JSON.stringify(itemId));

		const doc = await this.AssetDao.deleteItem(itemId);
		res.send('Deleted item....');
	}

	async completeAsset(req, res) {
		const completedAssets = Object.keys(req.body);
		const Assets = [];

		completedAssets.forEach((Asset) => {
			Assets.push(this.AssetDao.updateItem(Asset));
		});

		await Promise.all(Assets);

		res.send('Completed');
	}
}

module.exports = assetRoute;
