const ConditionDao = require('../models/ConditionDao');

class ConditionRoute {
	/**
    * Handles the various APIs for displaying and managing Conditions
    * @param {ConditionDao} ConditionDao
    */
	constructor(ConditionDao) {
		this.ConditionDao = ConditionDao;
	}
	async showConditions(req, res) {
		const querySpec = {
			query: 'SELECT * FROM ConditionData'
		};

		const items = await this.ConditionDao.find(querySpec);
		res.send(items);
	}

	async showCondition(req, res) {
		console.log(req.body);
		const querySpec = {
			query: 'SELECT * FROM ConditionData a where a.ConditionId = @ConditionId',
			parameters: [
				{
					name: '@ConditionId',
					value: req.body.ConditionId
				}
			]
		};

		const items = await this.ConditionDao.find(querySpec);
		res.send(JSON.stringify(items));
	}

	async addCondition(req, res) {
		const item = req.body;

		const doc = await this.ConditionDao.addItem(item);
		res.send('Completed adding....' + JSON.stringify(doc));
	}

	async deleteCondition(req, res) {
		const querySpec = {
			query: 'SELECT * FROM ConditionData a where a.ConditionId = @ConditionId',
			parameters: [
				{
					name: '@ConditionId',
					value: req.body.ConditionId
				}
			]
		};

		const items = await this.ConditionDao.find(querySpec);
		console.log('Body from select: ' + JSON.stringify(items));

		const itemId = items[0].id;
		console.log('Id from select: ' + JSON.stringify(itemId));

		const doc = await this.ConditionDao.deleteItem(itemId);
		res.send('Deleted item....');
	}

	async completeCondition(req, res) {
		const completedConditions = Object.keys(req.body);
		const Conditions = [];

		completedConditions.forEach((Condition) => {
			Conditions.push(this.ConditionDao.updateItem(Condition));
		});

		await Promise.all(Conditions);

		res.send('Completed');
	}
}

module.exports = ConditionRoute;