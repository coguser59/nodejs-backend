const AlertDao = require('../models/alertDao');

class alertRoute {
	/**
    * Handles the various APIs for displaying and managing Alerts
    * @param {AlertDao} AlertDao
    */
	constructor(AlertDao) {
		this.AlertDao = AlertDao;
	}
	
	async showAlerts(req, res) {
		const querySpec = {
			query: 'SELECT * FROM alertData'
			//    parameters: [
			//      {
			//        name: "@completed",
			//        value: false
			//      }
			//    ]
		};

		const items = await this.AlertDao.find(querySpec);
		res.send(items);
	}

	async showAlert(req, res) {
		console.log(req.body);
		const querySpec = {
			query: 'SELECT * FROM alertData a where a.alertId = @alertId',
			parameters: [
				{
					name: '@alertId',
					value: req.body.alertId
				}
			]
		};

		const items = await this.AlertDao.find(querySpec);
		res.send(JSON.stringify(items));
	}

	async showDailyAlertData(req, res) {
		console.log(req.body);
		const querySpec = {
			query: 'SELECT * FROM AlertData a where a.createdTimeStamp >= GetCurrentDateTime()',
			// parameters: [
			// 	{
			// 		name: '@alertId',
			// 		value: req.body.alertId
			// 	}
			// ]
		};

		const items = await this.AlertDao.find(querySpec);
		res.send(JSON.stringify(items));
	}

	async addAlert(req, res) {
		const item = req.body;

		const doc = await this.AlertDao.addItem(item);
		res.send('Completed adding....' + JSON.stringify(doc));
	}

	async deleteAlert(req, res) {
    
		const querySpec = {
			query: 'SELECT * FROM alertData a where a.alertId = @alertId',
			parameters: [
				{
					name: '@alertId',
					value: req.body.alertId
				}
			]
		};

		const items = await this.AlertDao.find(querySpec);
    console.log('Body from select: ' + JSON.stringify(items));

		const itemId = items[0].id;
		console.log('Id from select: ' + JSON.stringify(itemId));

		const doc = await this.AlertDao.deleteItem(itemId);
		res.send('Deleted item....');
	}

	async completeAlert(req, res) {
		const completedAlerts = Object.keys(req.body);
		const Alerts = [];

		completedAlerts.forEach((Alert) => {
			Alerts.push(this.AlertDao.updateItem(Alert));
		});

		await Promise.all(Alerts);

		res.send('Completed');
	}
}

module.exports = alertRoute;
