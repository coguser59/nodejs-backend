const UserDao = require('../models/UserDao');

class UserRoute {
	/**
    * Handles the various APIs for displaying and managing Users
    * @param {UserDao} UserDao
    */
	constructor(UserDao) {
		this.UserDao = UserDao;
	}
	async showUsers(req, res) {
		const querySpec = {
			query: 'SELECT * FROM UserData'
			//    parameters: [
			//      {
			//        name: "@completed",
			//        value: false
			//      }
			//    ]
		};

		const items = await this.UserDao.find(querySpec);
		res.send(items);
	}

	async showUser(req, res) {
		console.log(req.body);
		const querySpec = {
			query: 'SELECT * FROM UserData a where a.UserId = @UserId',
			parameters: [
				{
					name: '@UserId',
					value: req.body.UserId
				}
			]
		};

		const items = await this.UserDao.find(querySpec);
		res.send(JSON.stringify(items));
	}

	async addUser(req, res) {
		const item = req.body;

		const doc = await this.UserDao.addItem(item);
		res.send('Completed adding....' + JSON.stringify(doc));
	}

	async deleteUser(req, res) {
    
		const querySpec = {
			query: 'SELECT * FROM UserData a where a.UserId = @UserId',
			parameters: [
				{
					name: '@UserId',
					value: req.body.UserId
				}
			]
		};

		const items = await this.UserDao.find(querySpec);
    console.log('Body from select: ' + JSON.stringify(items));

		const itemId = items[0].id;
		console.log('Id from select: ' + JSON.stringify(itemId));

		const doc = await this.UserDao.deleteItem(itemId);
		res.send('Deleted item....');
	}

	async completeUser(req, res) {
		const completedUsers = Object.keys(req.body);
		const Users = [];

		completedUsers.forEach((User) => {
			Users.push(this.UserDao.updateItem(User));
		});

		await Promise.all(Users);

		res.send('Completed');
	}
}

module.exports = UserRoute;
