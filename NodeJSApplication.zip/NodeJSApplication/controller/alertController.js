const CosmosClient = require('@azure/cosmos').CosmosClient
var express = require('express');
var router = express.Router();

const AlertRoute = require('../routes/alertRoute');
const AlertDao = require('../models/alertDao');
const config = require('../config');

const cosmosClient = new CosmosClient({
	endpoint: config.host,
	key: config.authKey
});

const alertDao = new AlertDao(cosmosClient, config.databaseId, config.alertContainerId);
alertDao
.init((err) => {
	console.error(err);
})
.catch((err) => {
	console.error(err);
	console.error('Shutting down because there was an error settinig up the database.');
	process.exit(1);
});
const alertRoute = new AlertRoute(alertDao);

router.get('/getAlert', (req, res, next) => alertRoute.showAlert(req, res).catch(next));
router.get('/getAllAlert', (req, res, next) => alertRoute.showAlerts(req, res).catch(next));
router.post('/addAlert', (req, res, next) => alertRoute.addAlert(req, res).catch(next));
router.post('/deleteAlert', (req, res, next) => alertRoute.deleteAlert(req, res).catch(next));
router.post('/getAlertDayWiseHistory', (req, res, next) => alertRoute.showDailyAlertDataAlert(req, res).catch(next));

module.exports = router;