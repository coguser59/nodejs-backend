const CosmosClient = require('@azure/cosmos').CosmosClient
var express = require('express');
var router = express.Router();

const ConditionRoute = require('../routes/conditionRoute');
const ConditionDao = require('../models/conditionDao');
const config = require('../config');

const cosmosClient = new CosmosClient({
	endpoint: config.host,
	key: config.authKey
});

const conditionDao = new ConditionDao(cosmosClient, config.databaseId, config.conditionContainerId);
conditionDao
.init((err) => {
	console.error(err);
})
.catch((err) => {
	console.error(err);
	console.error('Shutting down because there was an error settinig up the database.');
	process.exit(1);
});
const conditionRoute = new ConditionRoute(conditionDao);

router.get('/getCondition', (req, res, next) => conditionRoute.showCondition(req, res).catch(next));
router.get('/getAllCondition', (req, res, next) => conditionRoute.showConditions(req, res).catch(next));
router.post('/addCondition', (req, res, next) => conditionRoute.addCondition(req, res).catch(next));
router.post('/deleteCondition', (req, res, next) => conditionRoute.deleteCondition(req, res).catch(next));

module.exports = router;