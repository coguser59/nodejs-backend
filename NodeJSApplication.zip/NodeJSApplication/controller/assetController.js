const CosmosClient = require('@azure/cosmos').CosmosClient
var express = require('express');
var router = express.Router();

const AssetRoute = require('../routes/assetRoute');
const AssetDao = require('../models/assetDao');
const config = require('../config');

const cosmosClient = new CosmosClient({
	endpoint: config.host,
	key: config.authKey
});

const assetDao = new AssetDao(cosmosClient, config.databaseId, config.assetContainerId);
assetDao
.init((err) => {
	console.error(err);
})
.catch((err) => {
	console.error(err);
	console.error('Shutting down because there was an error settinig up the database.');
	process.exit(1);
});
const assetRoute = new AssetRoute(assetDao);

router.get('/getAsset', (req, res, next) => assetRoute.showAsset(req, res).catch(next));
router.get('/getAllAsset', (req, res, next) => assetRoute.showAssets(req, res).catch(next));
router.post('/addAsset', (req, res, next) => assetRoute.addAsset(req, res).catch(next));
router.post('/deleteAsset', (req, res, next) => assetRoute.deleteAsset(req, res).catch(next));
router.get('/getAssetDayWiseHistory', (req, res, next) => assetRoute.showDailyAssetData(req, res).catch(next));

module.exports = router;