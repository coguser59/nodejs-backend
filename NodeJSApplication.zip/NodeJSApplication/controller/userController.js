const CosmosClient = require('@azure/cosmos').CosmosClient
var express = require('express');
var router = express.Router();

const UserRoute = require('../routes/UserRoute');
const UserDao = require('../models/UserDao');
const config = require('../config');

const cosmosClient = new CosmosClient({
	endpoint: config.host,
	key: config.authKey
});

const userDao = new UserDao(cosmosClient, config.databaseId, config.userContainerId);
userDao
.init((err) => {
	console.error(err);
})
.catch((err) => {
	console.error(err);
	console.error('Shutting down because there was an error settinig up the database.');
	process.exit(1);
});
const userRoute = new UserRoute(UserDao);

router.get('/getUser', (req, res, next) => userRoute.showUser(req, res).catch(next));
router.get('/getAllUser', (req, res, next) => userRoute.showUsers(req, res).catch(next));
router.post('/addUser', (req, res, next) => userRoute.addUser(req, res).catch(next));
router.post('/deleteUser', (req, res, next) => userRoute.deleteUser(req, res).catch(next));

module.exports = router;