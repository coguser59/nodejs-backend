var config = {}

config.endpoint = 'https://fsd-cosmosdb.documents.azure.com:443/'
config.key = 'pHlMSJqdhuTtpeVVBt7smEOxsC25VdO5qux7PCwI7G8gTsXaw7nJX3eSIjnhHPsxEunNiDyGA451g8DpRPi6PA=='
config.host = "https://fsd-cosmosdb.documents.azure.com:443/";
config.authKey = "pHlMSJqdhuTtpeVVBt7smEOxsC25VdO5qux7PCwI7G8gTsXaw7nJX3eSIjnhHPsxEunNiDyGA451g8DpRPi6PA==";
config.databaseId = "IoT FSD";
config.collectionId = "AssetData";
config.containerId = "AssetData";
config.userContainerId = "UserData";
config.assetContainerId = "AssetData";
config.alertContainerId = "AlertData";
config.conditionContainerId = "ConditionData";

module.exports = config

// const config = {};

// config.host = "https://fsd-cosmosdb.documents.azure.com:443/";
// config.authKey ='pHlMSJqdhuTtpeVVBt7smEOxsC25VdO5qux7PCwI7G8gTsXaw7nJX3eSIjnhHPsxEunNiDyGA451g8DpRPi6PA==';
// config.databaseId = "IoT FSD";

// if (config.host.includes("https://localhost:")) {
//   console.log("Local environment detected");
//   console.log("WARNING: Disabled checking of self-signed certs. Do not have this code in production.");
//   process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
//   console.log(`Go to http://localhost:${process.env.PORT || '3000'} to try the sample.`);
// }

// module.exports = config;